import { Dog } from './dog';


export const DOGS: Dog[] = [
  {'name':'Sisqo', 'age':'7 años', 'description':'', picture:'../../assets/images/dogs-pictures/0.jpg'},
  {'name':'Sisqo', 'age':'7 años', 'description':'', picture:'../../assets/images/dogs-pictures/1.jpg'},
  {'name':'Sisqo', 'age':'7 años', 'description':'', picture:'../../assets/images/dogs-pictures/2.jpg'},
  {'name':'Sisqo', 'age':'7 años', 'description':'', picture:'../../assets/images/dogs-pictures/3.jpg'},
  {'name':'Sisqo', 'age':'7 años', 'description':'', picture:'../../assets/images/dogs-pictures/4.jpg'},
  {'name':'Sisqo', 'age':'7 años', 'description':'', picture:'../../assets/images/dogs-pictures/5.jpg'},
];
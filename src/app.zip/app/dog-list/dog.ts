export class Dog {
  name: string;
  age: string;
  description: string;
  picture: string;
}


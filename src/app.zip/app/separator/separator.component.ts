
// Import component decorator
import { Component } from '@angular/core';

@Component({
  selector: 'separator',
  templateUrl: './separator.component.html',
  styleUrls: ['./separator.component.css']
  
})

// Component class
export class SeparatorComponent {
	title: string = '¡Adopta a un perrito!';
	icon: string = '¡Adopta a un perrito!';
	text: string = 'Aquí podrás encontrar algunos perritos esperando un hogar. No esperes más y conoce a tu próximo mejor amigo';
}
